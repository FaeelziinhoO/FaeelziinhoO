/*
  Criar um programa que solicite ao usuário que informe a sua 
altura e peso e calcule o seu índice de massa corporal (IMC). 
Em seguida, exibir uma mensagem informando se a pessoa está abaixo do peso, 
com peso normal, com sobrepeso, obesa ou muito obesa. 
 */
package exerciciostop10;

import javax.swing.JOptionPane;

public class Exercicio5 {

    public static void main(String[] args) {
        calculoIMC();
    }

    public static void calculoIMC() {
        JOptionPane.showMessageDialog(null, "Bem Vindo ao seu calculador de Índice de Massa Corporal.");
        double altura = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe sua Altura."));
        double peso = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe seu peso."));
        double imc = peso / (altura * altura);

        if (imc <= 18.5) {
            JOptionPane.showMessageDialog(null, imc+   "Abaixo do peso normal;");}
	 
        else if (imc >= 18.5 && imc <= 25) {
            JOptionPane.showMessageDialog(null,imc + "Peso normal;");
        }

        else if (imc >= 25 && imc<=30){
	JOptionPane.showMessageDialog(null,"Peso acima do normal;");
        }

        else{
            JOptionPane.showMessageDialog(null, "Obesidade batendo na sua porta, você deve se cuidar melhor.");
        }
    


        
}
    
}
