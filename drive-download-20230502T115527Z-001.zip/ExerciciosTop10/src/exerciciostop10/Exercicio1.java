/*
 1. Criar um programa que leia o nome e a idade de três pessoas e exiba o nome da pessoa
mais velha.
 */
package exerciciostop10;

import javax.swing.JOptionPane;

public class Exercicio1 {

    public static void main(String[] args) {

        maiorIdade();
        
    }

    public static void maiorIdade() {

        String nome1 = JOptionPane.showInputDialog("Digite seu nome :");
         Integer idade1 = Integer.parseInt(JOptionPane.showInputDialog("Digite sua idade"));
         
        String nome2 = JOptionPane.showInputDialog("Digite seu nome :"); 
        Integer idade2 = Integer.parseInt(JOptionPane.showInputDialog("Digite sua idade"));
        
        String nome3 = JOptionPane.showInputDialog("Digite seu nome :");
        Integer idade3 = Integer.parseInt(JOptionPane.showInputDialog("Digite sua idade"));
        
        if(idade1>=idade2 && idade1>=idade3){
            JOptionPane.showMessageDialog(null, nome1+ " tem a maior idade.");
        }
        
        if(idade2>=idade1 && idade2>=idade3){
            JOptionPane.showMessageDialog(null, nome2+ " tem a maior idade.");
        }
        if(idade3>=idade1 && idade3>=idade2){
            JOptionPane.showMessageDialog(null,nome3 + " tem a maior idade.");
            
        }

    }

}
