/*
 Criar um programa que leia dois números inteiros e exiba a soma
dos números pares entre eles (incluindo os números informados). 
Se os dois números forem iguais, verificar se ele é par e somá-lo caso seja. 
 */
package exerciciostop10;

import javax.swing.JOptionPane;


public class Exercicio8 {
    public static void main (String []args){
        somaDeNumeros();
    
}
    public static void somaDeNumeros(){
        Integer num1 = Integer.parseInt(JOptionPane.showInputDialog(null,"Digite o primeiro número."));
        Integer num2 = Integer.parseInt(JOptionPane.showInputDialog(null,"Digite o primeiro número."));
        
        if (num1%2 ==0 && num2 %2 ==0){
            double resultado = num1+num2;
            JOptionPane.showMessageDialog(null, "a soma do resultado resultado dos números pares é:"+resultado);
            
        }
       else{
            double resultado = num1+num2;
            JOptionPane.showMessageDialog(null, "Um ou os dois números não são números pares. Eu só ando com casais KKKKK\n" + resultado);
            
        }
    
}
}
