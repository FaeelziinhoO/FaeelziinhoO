package exerciciostop10;

import javax.swing.JOptionPane;

/*. Criar um programa que solicite ao usuário que informe os valores dos lados de um
triângulo e verifique se é possível formar um triângulo com essas medidas. Caso seja
possível, informar também qual é o tipo do triângulo (equilátero, isósceles ou escaleno).
 */
public class Exercicio2 {

    public static void main(String[] args) {
        valoresDosTriangulos();
    }

    public static void valoresDosTriangulos() {
        Integer lado1 = Integer.parseInt(JOptionPane.showInputDialog("Informe o valor de um lado do triângulo"));
        Integer lado2 = Integer.parseInt(JOptionPane.showInputDialog("Informe o valor de um lado do triângulo"));
        Integer lado3 = Integer.parseInt(JOptionPane.showInputDialog("Informe o valor de um lado do triângulo"));

        if (lado1 == lado2 && lado1 == lado3 && lado2 == lado3) {
            JOptionPane.showMessageDialog(null,"Ele é um equilátero");
        
        }
        else if  (lado1 == lado2 || lado1 == lado3 || lado2 == lado3){
            JOptionPane.showMessageDialog(null,"Ele é um Isóceles");
        }
        else{
            JOptionPane.showMessageDialog(null,"Ele é um Escaleno");
            
        }
    }


}
