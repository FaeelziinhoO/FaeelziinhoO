/*
Criar um programa que solicite ao usuário que informe a sua data de nascimento
(dia, mês e ano) e calcule a sua idade em anos completos
 */
package exerciciostop10;

import java.time.LocalDate;
import javax.swing.JOptionPane;
import java.time.Period;

public class Exercicio9 {

    public static void main(String[] args) {
        idadeEmAnos();
    }

    public static void idadeEmAnos() {
        Integer dia = Integer.parseInt(JOptionPane.showInputDialog("Entre com o dia de nascimento "));
        Integer mes = Integer.parseInt(JOptionPane.showInputDialog("Entre com seu mês de nascimento."));
        Integer ano = Integer.parseInt(JOptionPane.showInputDialog("Entre com seu ano de nascimento"));
        LocalDate dataNasci = LocalDate.of(ano, mes, dia);
        LocalDate dataAtual = LocalDate.now();
        int dataEmAnos = Period.between(dataNasci, dataAtual).getYears();
        JOptionPane.showMessageDialog(null, "Sua Idade em Anos é: " + dataEmAnos);
    }
}
