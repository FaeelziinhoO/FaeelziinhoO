/*
Criar um programa que solicite ao usuário que informe um número inteiro e exiba todos
os números primos menores ou iguais a esse número. 
 */
package exerciciostop10;

import javax.swing.JOptionPane;


public class ExerciciosTop10 {

    
    public static void main(String[] args) {
        calcularPrimos();
    }
    public static void calcularPrimos() {
        JOptionPane.showMessageDialog(null,"Bem-vindos ao indicador de números PRIMOS.");
        Integer num = Integer.parseInt(JOptionPane.showInputDialog(null,"Digite o número para iniciar." ));
        for(int i = 2;i<=num; i++){
            boolean primo = false;
        for (int div =2; div<i; div++){
        
        if (i % div==0){
            primo = true;
        
        }
            
        
        }
        if (primo == false ){
            System.out.println("Os números primos  de " +num+ "são:" +i);
        }
        }
        
    }
    
}
