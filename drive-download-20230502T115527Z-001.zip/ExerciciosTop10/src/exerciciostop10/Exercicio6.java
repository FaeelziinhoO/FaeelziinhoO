/*
 Criar um programa que leia a nota de três alunos em uma disciplina
e exiba a média aritmética das notas e a situação de cada aluno (aprovado, reprovado ou em recuperação).
A média mínima para aprovação é 7 pontos. Se a média for menor que 5 pontos, o aluno é reprovado. 
Se a média estiver entre 5 e 7 pontos, o aluno está em recuperação. 
 
 */
package exerciciostop10;

import javax.swing.JOptionPane;

public class Exercicio6 {

    public static void main(String[] args) {
        mediaDeNotas();
    }

    public static void mediaDeNotas() {
        JOptionPane.showMessageDialog(null, "Olá, você está no calculador de MÉDIA de NOTAS");
        double nota1 = Double.parseDouble(JOptionPane.showInputDialog(null, "Digita a primeira NOTA"));
        double nota2 = Double.parseDouble(JOptionPane.showInputDialog(null, "Digita a segunda NOTA"));
        double nota3 = Double.parseDouble(JOptionPane.showInputDialog(null, "Digita a terceira NOTA"));
        double media = (nota1 + nota2 + nota3) / 3;

        if (media < 5) {
            JOptionPane.showMessageDialog(null, "Você está  REPROVADO" + "\nPONTUAÇÃO: " + media);
        } else if (media >= 5 && media <= 7) {
            JOptionPane.showMessageDialog(null, "Você está  de RECUPERAÇÃO" + "\nPONTUAÇÃO: " + media);

        } else if (media > 7) {
            JOptionPane.showMessageDialog(null, "Você está APROVADO" + "\nPONTUAÇÃO: " + media);

        }

    }

}
