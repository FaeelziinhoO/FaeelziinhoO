/*
 3. Criar um programa que solicite ao usuário que
informe o valor do salário de um funcionário
e calcule o novo salário após um reajuste de 10%. 
 */
package exerciciostop10;

import static exerciciostop10.Exercicio2.valoresDosTriangulos;
import javax.swing.JOptionPane;

public class Exercicio3 {

    public static void main(String[] args) {
        reajusteSalarial();
    }

    public static void reajusteSalarial() {
        Double salarioFun = Double.parseDouble(JOptionPane.showInputDialog("Informe o salário do funcionário"));
         double reajuste = (salarioFun*10)/100;
         reajuste = salarioFun + reajuste;
         JOptionPane.showMessageDialog(null, "Seu novo salário após o reajuste será: " +reajuste);
         
    
    }
}
