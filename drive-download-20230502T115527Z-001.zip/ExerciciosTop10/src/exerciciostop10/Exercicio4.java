/*
. Criar um programa que leia dois números inteiros 
e exiba o resultado da operação escolhida pelo usuário 
(adição, subtração, multiplicação ou divisão). 
 
 */
package exerciciostop10;

import javax.swing.JOptionPane;

public class Exercicio4 {

    public static void main(String[] args) {
        equacoes();

    }

    public static void equacoes() {
        double valor1 = Double.parseDouble(JOptionPane.showInputDialog(null, "Insira o primeiro valor "));
        double valor2 = Double.parseDouble(JOptionPane.showInputDialog(null, "Insira o segundo valor "));
        Object[] options = {"Adição", "Subtração", "Multiplicação", "Divisão"};
        Object selectedValue = JOptionPane.showInputDialog(null, "Click na equação desejada", "Aviso",
                JOptionPane.INFORMATION_MESSAGE, null, options, options[3]);
        if (selectedValue == options[0]) {
            double resultado = valor1 + valor2;
            JOptionPane.showMessageDialog(null,"O resultado é: " +resultado);
        } else if (selectedValue == options[1]) {
            double resultado = valor1 - valor2;
            JOptionPane.showMessageDialog(null, "O resultado é: " +resultado);
        } else if (selectedValue == options[2]) {
            double resultado = valor1 * valor2;
            JOptionPane.showMessageDialog(null,"O resultado é: "+resultado);
            
        } else if (selectedValue == options[3]){
            double resultado = valor1 / valor2;
            JOptionPane.showMessageDialog(null, "O resultado é: "+resultado);
            
            
    }

}
}
