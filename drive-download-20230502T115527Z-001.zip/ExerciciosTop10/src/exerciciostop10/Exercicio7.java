/*
 Criar um programa que solicite ao usuário que informe o valor do raio de uma esfera e calcule o seu volume. 
 (v =4/3.PI .R3) PI = 3,14159265358979323846
 */
package exerciciostop10;

import javax.swing.JOptionPane;

public class Exercicio7 {
    public static void main(String []args){
        calculoDoVolume();
        
    }
    public static void calculoDoVolume(){
        double raio = Double.parseDouble(JOptionPane.showInputDialog(null,"Digite o raio de uma esfera."));
        
        double volume = (4.0/3.0)*3.14*(raio*raio*raio);
        JOptionPane.showMessageDialog(null,"O volume desta esfera é: " +volume);
        
    }
    
}
