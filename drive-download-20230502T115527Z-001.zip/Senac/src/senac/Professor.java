package senac;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 931128
 */
public class Professor extends Pessoa {
    private String especialidade;
    private int salario;{
}
    public void receberAumento(float aumento){
        this.salario+= aumento;//esta calculando o valor do salario mais aumento.
    }

    public String getEspecialidade() {
        return especialidade;
    }

    public void setEspecialidade(String especialidade) {
        this.especialidade = especialidade;
    }

    public int getSalario() {
        return salario;
    }

    public void setSalario(int salario) {
        this.salario = salario;
    }
}
