
package senac;

/**
 *
 * @author 931128
 */
public class Principal {

   
    public static void main(String[] args) 
    {
       Pessoa p1 = new Pessoa();
       Aluno p2 = new Aluno();
       Professor p3 = new Professor();
       Funcionário p4 = new Funcionário();
       
       p1.setNome("SerHumano");
        p1.setIdade (100);
        p1.setSexo ("indefinido");
       p2.setNome("Rafael");
        p2.setIdade (29);
        p2.setSexo ("masculino");
       p3.setNome("Júnior");
        p3.setIdade (26);
        p3.setSexo ("Masculino");
       p4.setNome("Valdete");
        p4.setIdade (35);
        p4.setSexo ("Feminino");
       
        
               
        System.out.println(p1.toString());
        System.out.println(p2.toString());
        System.out.println(p3.toString());
        System.out.println(p4.toString());
    }
    
}
