package senac;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 931128
 */
public class Pessoa {
    private int idade;
    private String sexo;
    private String nome;
    
    
   public void fazerAniversario()
   {
       this.idade++;
   }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    @Override
    public String toString() {
        return "Pessoa{" + "idade=" + idade + ", sexo=" + sexo + ", nome=" + nome + '}';
    }

    
    
    
}
