package senac;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 931128
 */
public class Aluno extends Pessoa {
    private int matricula;
    private String curso;

public void CancelarMatricula()
    {
        System.out.println("Matrícula"+ this.getMatricula()+"Cancelada");
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    
}
    

