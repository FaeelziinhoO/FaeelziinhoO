
public class Concessionaria {

    public static void main(String[] args) {
        VeiculoDeCarga veiculoCarga = new VeiculoDeCarga();
        veiculoCarga.setCargaMaxima(452);
        veiculoCarga.setChassi("454785");
        veiculoCarga.setCor("Amarelo");
        veiculoCarga.setPlaca("GtO8582");
        veiculoCarga.setModelo("JohnDeere");

    }

}
