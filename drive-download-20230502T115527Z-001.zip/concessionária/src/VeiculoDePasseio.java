
public class VeiculoDePasseio extends Veiculos {
    private int quantidadeDePassageiros;
    
    public VeiculoDePasseio(){
    
    
    }

    public int getQuantidadeDePassageiros() {
        return quantidadeDePassageiros;
    }

    public void setQuantidadeDePassageiros(int quantidadeDePassageiros) {
        this.quantidadeDePassageiros = quantidadeDePassageiros;
    }
        
    
}

    

