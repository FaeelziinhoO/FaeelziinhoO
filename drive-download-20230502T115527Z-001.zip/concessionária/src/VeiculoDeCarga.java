
public class VeiculoDeCarga extends Veiculos {
    private int cargaMaxima;
    public VeiculoDeCarga(){}

    public int getCargaMaxima() {
        return cargaMaxima;
    }

    public void setCargaMaxima(int cargaMaxima) {
        this.cargaMaxima = cargaMaxima;
    }
        
   

    
}
