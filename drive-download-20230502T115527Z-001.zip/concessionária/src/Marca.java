
public class Marca {

    private int descricao;
    private int logoTipo;

    public Marca() {

    }

    public int getDescricao() {
        return descricao;
    }

    public void setDescricao(int descricao) {
        this.descricao = descricao;
    }

    public int getLogoTipo() {
        return logoTipo;
    }

    public void setLogoTipo(int logoTipo) {
        this.logoTipo = logoTipo;
    }

}
