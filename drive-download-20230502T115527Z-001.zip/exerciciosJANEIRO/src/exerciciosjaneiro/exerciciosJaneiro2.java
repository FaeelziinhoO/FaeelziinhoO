
package exerciciosjaneiro;

import java.util.Scanner;


public class exerciciosJaneiro2 {
    public static void main(String[] args) {
        
    
    int total= 0, valor=0;
    boolean terminar=false;
   
    Scanner scan = new Scanner(System.in);
   
    do{
    System.out.println("Digite um número.");
        valor = scan.nextInt();
        
        if (valor>=0){ 
        
            total += valor;
        }
           
        else{
               System.out.println("valor Inválido.");
            terminar=true;
                 
                }        
        if (total > 20){
            terminar= true;
            }
            System.out.println("Total:{"+total+"}");
        
   
    }while(terminar != true);
       System.out.println("Finalzin");
      
    
 }
}

