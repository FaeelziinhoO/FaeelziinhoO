
package exerciciosjaneiro;

import java.util.Scanner;

public class Calculadora {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int num;
    
        System.out.println("Tabuada do número");
        num = scan.nextInt();
        for(int i=1; i<=10; i++){
            System.out.println(+num+"*"+i+"="+num*i);
        }

    }
}
  