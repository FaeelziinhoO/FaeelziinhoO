package caixasdemensagens;

import javax.swing.JOptionPane;

public class CaixasDeMensagens {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Object[] options = {"OK", "CANCELAR", "VOLTAR"}; 
        JOptionPane.showMessageDialog(null, "Você conseguiu");
        Object[] itens = {"Joven", "adulto", "empate"};
        JOptionPane.showInputDialog(null, "Você conseguiu");
        Object selectvalue = JOptionPane.showInputDialog(null, "ESCOLHE AÊ",
                "opção", JOptionPane.INFORMATION_MESSAGE, null, itens, itens[0]);

        JOptionPane.showConfirmDialog(null, "Você conseguiu");
        JOptionPane.showOptionDialog(null, "Click em OK para continuar", "Aviso",
                JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, null, options, options[0]);

    }

}
