
package exerciciosbasicos;

import java.util.Scanner;


public class ExerciciosBasicos {

   
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.print("Entre com o 1° valor ");
        double valor1 = scan.nextDouble();
         System.out.print("Entre com o 2° valor ");
         double valor2 = scan.nextDouble();
        
         
         System.out.println("a SOMA          destes valores são: " + soma(valor1,valor2));
         System.out.println("a SUBTRAÇÃO     destes valores são: " + subtracao(valor1,valor2));
         System.out.println("a MULTIPLICAÇÃO destes valores são: " + multiplicacao(valor1,valor2));
         System.out.println("a DIVISÃO       destes valores são: " + divisao(valor1,valor2));
         
 
    }
    public static double soma(double valor1, double valor2){
        double soma = valor1 + valor2;
        return soma;   
    }
    public static double subtracao (double valor1, double valor2){
        double subtracao = valor1 - valor2;
        return subtracao;
    }
    public static double multiplicacao(double valor1, double valor2){
        double multiplicacao = valor1 * valor2;
        return multiplicacao;
    }
    public static double divisao(double valor1, double valor2){
        double divisao = valor1 / valor2;
        return divisao;
    }
    
    
    
}
