package exemploConstruction;

public class SistemaCadstro {

    public static void main(String[] args) {
        Pessoa pessoa2 = new Pessoa("Rafael José", "012.152.018-56", "Rua das Pedras ", 45);
        Pessoa pessoa3 = new Pessoa("Amarildo", "152.158.147-56", "Rua Elementar", 54);
        

    }

}
