package escolaa;

public class Professor {

    public String nome;
    public double salario;
    public String disciplina;
    public int horario;

    public Professor(String nome, double salario, String disciplina, int horario) {
        this.nome = nome;
        this.salario = salario;
        this.disciplina = disciplina;
        this.horario = horario;
    }
    

    public void ensina() {

    }

    public void chegada() {

    }

    public void saida() {

    }

    public void receberSalario() {

    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public String getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(String disciplina) {
        this.disciplina = disciplina;
    }

    public int getHorario() {
        return horario;
    }

    public void setHorario(int horario) {
        this.horario = horario;
    }

    public void imprimir() {
        System.out.println("Nome" + this.nome);
        System.out.println("Salário" + this.salario);
        System.out.println("Disciplina" + this.disciplina);
        System.out.println("Horário" + this.horario + "\n\n");

    }

}
