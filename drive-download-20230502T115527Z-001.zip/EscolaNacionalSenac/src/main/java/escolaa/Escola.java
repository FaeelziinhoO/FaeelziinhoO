package escolaa;

public class Escola {

    public static void main(String[] args) {
        Curso curso1 = new Curso("1200", "15", "Diego e Vanderley", "TDS");
        Estudante estudante1 = new Estudante("Efeso", 30, 185247, "Rua Bemtivi");
        Professor professor1 = new Professor("Diego e Vandeley", 100000, "TDS", 4);
        
        curso1.imprimir();
        estudante1.imprimir();
        professor1.imprimir();
    }
        

}
