package escolaa;

/**
 *
 * Crie uma classe Estudante com suas respectivas funções utilizando o diagrama
 * de classe a seguir.
 *
 * @author FaaelzinhoO
 */
public class Estudante {

    public String nome;
    public int idade;
    public int matricula;
    public String endereco;

    public Estudante(String nome, int idade, int matricula, String endereco) {
        this.nome = nome;
        this.idade = idade;
        this.matricula = matricula;
        this.endereco = endereco;
    }
    

    public void estudar() {

    }

    public void realizarAtividades() {

    }

    public void sofre() {

    }

    public void realizaProvas() {

    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public void imprimir() {
        System.out.println("Nome" + this.nome);
        System.out.println("Idade" + this.idade);
        System.out.println("Matrícula" + this.matricula);
        System.out.println("Endereço" + this.endereco + "\n\n");

    }
}
