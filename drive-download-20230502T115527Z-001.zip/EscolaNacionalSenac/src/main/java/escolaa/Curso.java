package escolaa;

public class Curso {

    public String cargaHoraria;
    public String quantidadeAlunos;
    public String docente;
    public String materia;

    public Curso(String cargaHoraria, String quantidadeAlunos, String docente, String materia) {
        this.cargaHoraria = cargaHoraria;
        this.quantidadeAlunos = quantidadeAlunos;
        this.docente = docente;
        this.materia = materia;
    }
    
    

    public void matricular() {

    }

    public void capicitar() {

    }

    public void atividades() {

    }

    public void provas() {

    }

    public void fazerAlunoSofrer() {

    }

    public String getCargaHoraria() {
        return cargaHoraria;
    }

    public void setCargaHoraria(String cargaHoraria) {
        this.cargaHoraria = cargaHoraria;
    }

    public String getQuantidadeAlunos() {
        return quantidadeAlunos;
    }

    public void setQuantidadeAlunos(String quantidadeAlunos) {
        this.quantidadeAlunos = quantidadeAlunos;
    }

    public String getDocente() {
        return docente;
    }

    public void setDocente(String docente) {
        this.docente = docente;
    }

    public String getMateria() {
        return materia;
    }

    public void setMateria(String materia) {
        this.materia = materia;
    }

    public void imprimir() {
        System.out.println("Carga Horária" + cargaHoraria);
        System.out.println("Quantidade de Anlunos" + quantidadeAlunos);
        System.out.println("Docente" + docente);
        System.out.println("Matéria" + materia + "\n\n");

    }
}
