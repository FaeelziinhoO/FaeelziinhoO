
import java.util.Scanner;

/*Ler um conjunto de números reais, armazenando-o
em vetor e calcular o quadrado dos componentes deste 
vetor, armazenando o resultado em outro vetor.
Os conjuntos tem 10 elementos cada. 
imprima todos os conjuntos*/
public class Exercício3VETORES {

    public static void main(String[] args) {

        int numero[] = new int[10];
        Scanner scan = new Scanner(System.in);

        for (int i = 0; i < 10; i++) {
            System.out.println("Digite o °" + (i + 1) + "campeão.");
            numero[i] = scan.nextInt();

        }
        for (int i = 0; i < 10; i++) {
            numero[i] *= numero[i];

            System.out.println("O quadrado do número " + (i + 1) + " é:" + numero[i]);

        }

    }
}
