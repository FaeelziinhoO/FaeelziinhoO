/*Faça um programa que peça ao
usuário para digitar 10 números reais.
Ao final imprima cada valor na ordem
inversa à leitura.*/
import java.util.Scanner;

public class Exercicio2Vetores {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int numero[] = new int[10];
        
        for (int i = 0; i <= 9; i++) {
            System.out.println("Digite o °"+(i+1)+"campeão.");
            numero[i] = scan.nextInt();
        }
        System.out.println("Os números na ordem decrescentes são: ");
        for (int i = 9; i >=0; i--){
            System.out.println(+numero[i]);
            
        }

    }
}
