/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author 931128
 */
public class Caneta {
    String modelo;
    String cor;
    float ponta;
    int carga;
    boolean tampada;
    
     void status ()
        {
            System.out.println("Modelo:" +this.modelo);
    }
     void escrever()
     {
        if(this.tampada == true)
        {
            System.out.println("Erro! não pode escrever fera.");
        }
        else  
        {
            System.out.println("");
        } 
     }
     void tampada()
     {
         this. tampada = true;
     }
     void destampada()
     {
        this. tampada = false; 
     }
     
     }
     

