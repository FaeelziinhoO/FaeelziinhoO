/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula4;

/**
 *
 * @author 931128
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     Caneta c1 = new Caneta("Compact",0.5f);
     c1.status();
     // c1.setModelo("NICK");
    //  c1.setPonta(0.4f);
    //c1.status();
    }
    
}
