/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author 931128
 */
public class Borracha {
    public String marca;
    public String cor; 
    protected float tamanho;
    protected float peso;

    public boolean apagar;
    {
        
       if(this.apagar == true)
       {
           System.out.println("Erro! não posso apagar FERA");
    }
        else
        {
            System.out.println("Estou apagando . ");
        }
        
       
           

}
                

    
    
}
