

/**
 *
 * @author FaeelziinhoO_DEV
 */
public class Gato {

    public String nomeGato;
    public String raca;
    public boolean genero;
    
    public void alimenta(){
        
    }
    public void nescessidades(){
        
    }
    public void cruza(){
        
    }
    public void mia(){
        
    }
    
    
    }
    
    


