/**
 *
 * @author  FaeelziinhoO_DEV
 */
public class Cliente {
    public String nome;
    public String endereco;
    public String telefone;
    public String nomeAnimal;
    public String cpf;
    public String genero;
    
    public void paga(){
        
    }
    public void compra(){
        
    }
    public void agendaServico(){
        
    }
    public void imprimir(){
        System.out.println("Nome do cliente" +nome+"\n\n");
        System.out.println("Cadastro de Pessoa Física do cliente" +cpf+"\n\n");
        System.out.println("Endereço do cliente" +endereco+"\n\n");
        System.out.println("Número de telefone do cliente" +telefone+"\n\n");
    }
    
}
