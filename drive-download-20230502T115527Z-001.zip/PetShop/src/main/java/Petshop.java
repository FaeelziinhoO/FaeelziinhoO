
import java.util.Scanner;


/*
 * @author FaeelziinhoO
 */
public class Petshop {

    public static void main(String[] args) {
      
        
        Cliente cliente1 = new Cliente();
        cliente1.nome = "Tirulipa";
        cliente1.cpf = "12345678910";
        cliente1.endereco = "Rua dos Sorrisos";
        cliente1.telefone = "151713458";
        
        cliente1.imprimir();

        Cliente cliente2 = new Cliente();
        cliente2.nome = "Tiririca";
        cliente2.cpf = "10987654321";
        cliente2.endereco = "Rua das Alegrias";
        cliente2.telefone = "87654321";
         cliente2.imprimir();
        
       

    }

}
