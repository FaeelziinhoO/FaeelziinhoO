

/**
 *
 * @author  FaeelziinhoO_DEV
 */
public class Cachorro {
    public String nomeCao;
    public String raca;
    public boolean genero;
    
    public void alimenta(){
        
    }
    public void nescessidades(){
        
    }
    public void cruza(){
        
    }
    public void late(){
        
    }
    
    
}
