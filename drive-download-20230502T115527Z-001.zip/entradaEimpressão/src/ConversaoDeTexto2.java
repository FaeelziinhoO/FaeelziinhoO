
import javax.swing.JOptionPane;


public class ConversaoDeTexto2 {

    public static void main(String[] args) {
calculoDesconto();
}
public static void calculoDesconto() {
String valorProdutoStr = JOptionPane.showInputDialog("Digite o valor do produto:");
String descontoStr = JOptionPane.showInputDialog("Digite o percentual de| desconto:");

double valorProduto = Double.parseDouble(valorProdutoStr);
double desconto = Double.parseDouble(descontoStr);

double valorDesconto = valorProduto * (desconto / 100);
double valorTotal = valorProduto - valorDesconto;

JOptionPane.showMessageDialog(null, "O valor do desconto &: R$ " + valorDesconto
+ "\nO valor total com o desconto é&: R$ " + valorTotal);
    
}
}