

import javax.swing.JOptionPane;

public class ConversaoDetexto {

   
    
        public static void main(String[] args) {
            calculoDesconto();
        }
            public static void calculoDesconto(){
                
            
            double num1 = Double.parseDouble(JOptionPane.showInputDialog("Digite o primeiro nimero:"));
            double num2 = Double.parseDouble(JOptionPane.showInputDialog("Digite o segundo nimero:"));
            
            

            double resultado = num1 + num2;

            JOptionPane.showMessageDialog(null, "A soma é: " + resultado);
        }
}
        
   
