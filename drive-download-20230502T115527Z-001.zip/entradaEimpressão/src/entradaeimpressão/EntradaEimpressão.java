package entradaeimpressão;

import javax.swing.JOptionPane;

public class EntradaEimpressão {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
       String nome = JOptionPane.showInputDialog(null, "Você conseguiu");
           JOptionPane.showMessageDialog(null, nome);
    }
           

        
    }
