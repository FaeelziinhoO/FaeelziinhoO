
package projetoufc;

public class ProjetoUFC {

    public static void main(String[] args) {
        Lutador lutador1 = new Lutador("Charles DUBRONKS", "Brasileiro", 29, 75, 1.80, 2, 0, 2);
        lutador1.apresentar();
        lutador1.status();

        Lutador lutador2 = new Lutador("Jack Lee", "Russo", 31, 76, 1.80, 0, 0, 0);
        lutador2.apresentar();
        lutador2.status();
        
        Luta batalha1 = new Luta();
        
        batalha1.marcarLuta(lutador1, lutador2);
        batalha1.lutar(lutador1, lutador2);
        
        System.out.println(lutador1.getNome());
        lutador1.status();
        
        System.out.println(lutador2.getNome());
        lutador2.status();
        
        
        
        

    }
}
