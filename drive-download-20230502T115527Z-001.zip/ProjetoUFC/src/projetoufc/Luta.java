package projetoufc;

import java.util.Random;

public class Luta {

    private Lutador desafiado;
    private Lutador desafiante;
    private int rounds;
    private boolean aprovado;
    Random aleatorio = new Random();

    public void marcarLuta(Lutador desafiado, Lutador desafiante) {
        if (desafiado.getCategoria() == desafiante.getCategoria()&& desafiado!=desafiante) {
            setAprovado(true);
            System.out.println("Luta foi aprovada");
        }else{
            setAprovado(false);
            System.out.println("Luta irregular (não aprovada)");
        }

    }

    public void lutar(Lutador desafiante, Lutador desafiado) {
        if (this.aprovado == true) {
            int vencedor = aleatorio.nextInt(3);
            switch (vencedor) {
                case 0:
                    System.out.println(desafiado.getNome()+ " é o vencedor");
                    desafiado.ganharLuta();
                    desafiante.perderLuta();
                    
                    break;
                case 1:
                    System.out.println(desafiante.getNome() + " é o vencedor");
                    desafiante.ganharLuta();
                    desafiado.perderLuta();
                    break;
                case 2:
                    System.out.println("Empate");
                    desafiado.empatarLuta();
                    desafiante.empatarLuta();
            }
        }else{
            System.out.println("Luta não foi aprovada anteriormente!");
        }
    }

    public Lutador getDesafiado() {
        return desafiado;
    }

    public void setDesafiado(Lutador desafiado) {
        this.desafiado = desafiado;
    }

    public Lutador getDesafiante() {
        return desafiante;
    }

    public void setDesafiante(Lutador desafiante) {
        this.desafiante = desafiante;
    }

    public int getRounds() {
        return rounds;
    }

    public void setRounds(int rounds) {
        this.rounds = rounds;
    }

    public boolean getAprovado() {
        return aprovado;
    }

    public void setAprovado(boolean aprovado) {
        this.aprovado = aprovado;
    }

}
