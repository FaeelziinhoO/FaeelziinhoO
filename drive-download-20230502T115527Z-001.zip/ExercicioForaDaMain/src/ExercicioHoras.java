    
import java.util.Scanner;

/*
 A partir da hora do dia, informe a mensagem adequada: Bom dia, Boa
tarde e Boa noite.
Lembrando que deve ser realizado em um método separado da
main().
 */
public class ExercicioHoras {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.print("Digite as horas vou te falar em qual período do dia você se encontra...");
        double horas = scan.nextDouble();
        horas(horas);
    }

    public static void horas(double horas) {

        if (horas >= 1.00 && horas <= 12.59) {
            System.out.println("Bom dia:" + horas +" Horas.");
        } else if (horas >= 13.00 && horas <= 18.59) {
            System.out.println("Boa tarde:" + horas +" Horas.");
        } else {
            System.out.println("Boa noite" + horas +" Horas.");
            
        }

    }

}
    

